module Main where

import Graphics.Gloss
import Window 
import Snake
import Util
import Hangman
import ForCobrinha


main :: IO ()
main = display window windowBackgroundColor drawForCobrinha

