module Snake where

import Graphics.Gloss
import Util


-- Settings
snakeAreaWidth = 450 :: Float
snakeAreaHeight = 450 :: Float
snakeAreaTranslateX = 0 :: Float
snakeAreaTranslateY = -50 :: Float
snakeAreaColor = dark (dark green)

type Coordinate = (Int, Int)
type Snake = [Coordinate]
type Direction = (Int, Int)
type Food = Coordinate

up, down, left, right :: Direction
up = (0, 1)
down = (0, -1)
left = (-1, 0)
right = (1, 0)


-- Snake Game
data SnakeGame = Game
  { snakeBody :: Snake,
    direction :: Direction
  }

snakeBackground :: Picture
snakeBackground = createBackground snakeAreaTranslateX snakeAreaTranslateY 
                                   snakeAreaColor snakeAreaWidth snakeAreaHeight


