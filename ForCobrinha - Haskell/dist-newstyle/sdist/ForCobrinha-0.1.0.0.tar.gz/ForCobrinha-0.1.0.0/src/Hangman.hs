module Hangman where

import Graphics.Gloss
import Util


-- Settings
hangmanAreaWidth = 450 :: Float
hangmanAreaHeight = 75 :: Float
hangmanAreaTranslateX = 0 :: Float
hangmanAreaTranslateY = 238 :: Float
hangmanAreaColor = dark (dark green)


-- Hangman Game
hangmanBackground :: Picture
hangmanBackground = createBackground hangmanAreaTranslateX hangmanAreaTranslateY 
                                     hangmanAreaColor hangmanAreaWidth hangmanAreaHeight
