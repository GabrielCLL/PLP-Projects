module Util where

import Graphics.Gloss


createBackground :: Float -- ^ Translate position x
           -> Float -- ^ Translate position y
           -> Color -- ^ Background color
           -> Float -- ^ Width
           -> Float -- ^ Height
           -> Picture -- ^ A picture of this background
createBackground x y my_color width height = translate x y
                             (color my_color (rectangleSolid width height))

