module Window where

import Graphics.Gloss
import ForCobrinha (nameGame)


-- Settings
windowWidth = 500 :: Int
windowHeight = 600 :: Int
windowOffset = 0 :: Int
windowColor = dark white


-- Window 
window :: Display
window = InWindow nameGame (windowWidth, windowHeight) (windowOffset, windowOffset)

windowBackgroundColor :: Color
windowBackgroundColor = windowColor
