module ForCobrinha where

import Graphics.Gloss
import Snake
import Hangman


-- Settings
nameGame = "ForCobrinha" :: String
fps = 5 :: Int


-- ForCobrinha
drawForCobrinha :: Picture
drawForCobrinha = pictures [snakeBackground, hangmanBackground]
